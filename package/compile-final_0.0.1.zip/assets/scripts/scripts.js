

/* Mobile SwipeUP remove */
setTimeout(function(){
  document.getElementById('swipeind').remove();
}, 7000);
